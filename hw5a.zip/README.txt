Sample README.txt

Eventually your report about how you implemented thread synchronization
in the server should go here

Students:
Rupa Chalavadi (rchalav1)
Maverick Espinosa (mespin11)