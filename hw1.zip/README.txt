TODO: add information about contributions of team member(s)
for MS1 I did not work with a partner.