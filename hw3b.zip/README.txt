Student names:
    1. Maverick Espinosa (mespin11)
    2. Rupasri Chalavadi (rchalav1)

    Maverick: worked on command line arguments validation, created framework (mapped out datastructures)
    Rupasri: worked on makefile, wrote up logic code

    Both worked together to discuss logic of the stores and loads, and worked together to debug (took forever lol) the functions.