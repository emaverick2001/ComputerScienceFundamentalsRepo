TODO: add information about contributions of team member(s)

Student 1: Rupasri Chalavadi; JHED: rchalav1
Student 2: Maverick Espinosa; JHED: mespin11

Contributions:
Note: Worked through pseudocode for all functions together, then divided up the implementations
c_wcfuncs - wc_hash (both), wc_str_compare (Rupa), wc_str_copy (both), wc_isspace(Maverick), wc_isalpha (Maverick),
wc_read_next (Maverick), wc_to_lower (Rupa), wc_trim_non_alpha (Rupa), wc_find_or_insert (Rupa), wc_dict_find_or_insert (Maverick), wc_free_chain (Maverick)
c main function (both)

asm_wcfuncs - 
wc_isspace (Rupa)
wc_isalpha (Maverick)
wc_str_compare (Rupa)
wc_hash (both)
wc_str_copy (Rupa)
wc_readnext (Maverick)
wc_tolower (Rupa)
wc_trim_non_alpha (Maverick)
wc_find_or_insert (Maverick)
wc_dict_find_or_insert (Rupa)
wc_free_chain (Maverick)

asm_main - both