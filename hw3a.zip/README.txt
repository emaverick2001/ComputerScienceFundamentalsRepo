Student names:
    1. Maverick Espinosa (mespin11)
    2. Rupasri Chalavadi (rchalav1)

    Maverick worked on command line arguments
    Rupasri worked on makefile