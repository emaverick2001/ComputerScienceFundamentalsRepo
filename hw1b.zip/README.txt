TODO: add information about contributions of team member(s)

Worked on add, subtract, negate, cuint256_create_from_u32, uint256_create, uint256_get_bits independely.

Collaborated on create_from_hex, format_as_hex, rotate_left, rotate_right

Student names:
    1. Maverick Espinosa (mespin11)
    2. Rupasri Chalavadi (rchalav1)